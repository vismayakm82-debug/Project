function searchHosting() {
  const searchText = document.getElementById("search").value.toLowerCase();
  const cards = document.querySelectorAll(".card");

  cards.forEach((card) => {
    const providerName = card.querySelector("h3").textContent.toLowerCase();
    card.style.display = providerName.includes(searchText) ? "block" : "none";
  });
}

function showInfo(name) {
  alert("You selected " + name + " hosting provider.");
}

function checkDomain() {
  const domain = document.getElementById("domain").value.trim();
  const result = document.getElementById("result");

  if (domain === "") {
    result.textContent = "Please enter a domain name.";
  } else {
    result.textContent = "Demo search completed for: " + domain +
      ". Actual availability must be checked with a domain registrar.";
  }
}
